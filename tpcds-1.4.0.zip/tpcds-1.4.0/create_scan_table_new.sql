
create database if not exists ${DB} LOCATION '${LOCATION}';
use ${DB};

create table customer_address
stored as ${FILE} LOCATION '${LOCATION}/customer_address'
as select * from ${SOURCE}.customer_address;

drop table if exists customer_address;
create table customer_address
stored as ${FILE} LOCATION '${LOCATION}/customer_address'
as select * from ${SOURCE}.customer_address;

drop table if exists customer_demographics;
create table customer_demographics
stored as ${FILE}  LOCATION '${LOCATION}/customer_demographics'
as select * from ${SOURCE}.customer_demographics;

drop table if exists date_dim;
create table date_dim
stored as ${FILE}  LOCATION '${LOCATION}/date_dim'
as select * from ${SOURCE}.date_dim;

drop table if exists warehouse;
create table warehouse
stored as ${FILE} LOCATION '${LOCATION}/warehouse'
as select * from ${SOURCE}.warehouse;

drop table if exists ship_mode;
create table ship_mode
stored as ${FILE} LOCATION '${LOCATION}/ship_mode'
as select * from ${SOURCE}.ship_mode;

drop table if exists time_dim;
create table time_dim
stored as ${FILE} LOCATION '${LOCATION}/time_dim'
as select * from ${SOURCE}.time_dim;

drop table if exists reason;
create table reason
stored as ${FILE} LOCATION '${LOCATION}/reason'
as select * from ${SOURCE}.reason;

drop table if exists income_band;
create table income_band
stored as ${FILE} LOCATION '${LOCATION}/reason'
as select * from ${SOURCE}.income_band;

drop table if exists item;
create table item
stored as ${FILE} LOCATION '${LOCATION}/item'
as select * from ${SOURCE}.item;

drop table if exists store;
create table store
stored as ${FILE} LOCATION '${LOCATION}/store'
as select * from ${SOURCE}.store;

drop table if exists call_center;
create table call_center
stored as ${FILE} LOCATION '${LOCATION}/call_center'
as select * from ${SOURCE}.call_center;

drop table if exists customer;
create table customer
stored as ${FILE} LOCATION '${LOCATION}/customer'
as select * from ${SOURCE}.customer;

drop table if exists web_site;
create table web_site
stored as ${FILE} LOCATION '${LOCATION}/web_site'
as select * from ${SOURCE}.web_site;

drop table if exists store_returns;
create table store_returns
stored as ${FILE} LOCATION '${LOCATION}/store_returns'
as select * from ${SOURCE}.store_returns;

drop table if exists household_demographics;
create table household_demographics
stored as ${FILE} LOCATION '${LOCATION}/household_demographics'
as select * from ${SOURCE}.household_demographics;

drop table if exists web_page;
create table web_page
stored as ${FILE} LOCATION '${LOCATION}/web_page'
as select * from ${SOURCE}.web_page;

drop table if exists promotion;
create table promotion
stored as ${FILE} LOCATION '${LOCATION}/promotion'
as select * from ${SOURCE}.promotion;

drop table if exists catalog_page;
create table catalog_page
stored as ${FILE} LOCATION '${LOCATION}/catalog_page'
as select * from ${SOURCE}.catalog_page;

drop table if exists inventory;
create table inventory
stored as ${FILE} LOCATION '${LOCATION}/inventory'
as select * from ${SOURCE}.inventory;

drop table if exists catalog_returns;
create table catalog_returns
stored as ${FILE} LOCATION '${LOCATION}/catalog_returns'
as select * from ${SOURCE}.catalog_returns;

drop table if exists web_returns;
create table web_returns
stored as ${FILE} LOCATION '${LOCATION}/web_returns'
as select * from ${SOURCE}.web_returns;

drop table if exists web_sales;
create table web_sales
stored as ${FILE} LOCATION '${LOCATION}/web_sales'
as select * from ${SOURCE}.web_sales;

drop table if exists catalog_sales;
create table catalog_sales
stored as ${FILE} LOCATION '${LOCATION}/catalog_sales'
as select * from ${SOURCE}.catalog_sales;

drop table if exists store_sales;
create table store_sales
stored as ${FILE} LOCATION '${LOCATION}/store_sales'
as select * from ${SOURCE}.store_sales;

