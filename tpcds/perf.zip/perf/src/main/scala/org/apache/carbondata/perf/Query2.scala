/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.carbondata.perf

import org.apache.spark.sql.SparkSession

/**
 * Query2
 */
object Query2 {
  def main(args: Array[String]): Unit = {
    val spark = PerfUtils.createSparkSession("Query2", 4)
    // createTable(spark)
    // loaddata(spark)
    System.out.println("start carbon query:")
    val t1 = System.currentTimeMillis()
    query2(spark)
    val t2 = System.currentTimeMillis()
    System.out.println(s"taken time: ${t2 - t1 } ms")
    // createParquet(spark)
    System.out.println("start parquet query:")
    query2Parquet(spark)
    val t3 = System.currentTimeMillis()
    System.out.println(s"taken time: ${t3 - t2 } ms")
    Thread.sleep(1000000)
  }

  def createParquet(spark: SparkSession): Unit = {
    spark.sql("create table if not exists web_sales_parquet using parquet as select * from web_sales")
    spark.sql("create table if not exists catalog_sales_parquet using parquet as select * from catalog_sales")
    spark.sql("create table if not exists date_dim_parquet using parquet as select * from date_dim")
  }

  def query2(spark: SparkSession): Unit = {
    spark.sql(
      """
        |with wscs as
        | (select sold_date_sk
        |        ,sales_price
        |  from (select ws_sold_date_sk sold_date_sk
        |              ,ws_ext_sales_price sales_price
        |        from web_sales) x
        |        union all
        |       (select cs_sold_date_sk sold_date_sk
        |              ,cs_ext_sales_price sales_price
        |        from catalog_sales)),
        | wswscs as
        | (select d_week_seq,
        |        sum(case when (d_day_name='Sunday') then sales_price else null end) sun_sales,
        |        sum(case when (d_day_name='Monday') then sales_price else null end) mon_sales,
        |        sum(case when (d_day_name='Tuesday') then sales_price else  null end) tue_sales,
        |        sum(case when (d_day_name='Wednesday') then sales_price else null end) wed_sales,
        |        sum(case when (d_day_name='Thursday') then sales_price else null end) thu_sales,
        |        sum(case when (d_day_name='Friday') then sales_price else null end) fri_sales,
        |        sum(case when (d_day_name='Saturday') then sales_price else null end) sat_sales
        | from wscs
        |     ,date_dim
        | where d_date_sk = sold_date_sk
        | group by d_week_seq)
        | select d_week_seq1
        |       ,round(sun_sales1/sun_sales2,2)
        |       ,round(mon_sales1/mon_sales2,2)
        |       ,round(tue_sales1/tue_sales2,2)
        |       ,round(wed_sales1/wed_sales2,2)
        |       ,round(thu_sales1/thu_sales2,2)
        |       ,round(fri_sales1/fri_sales2,2)
        |       ,round(sat_sales1/sat_sales2,2)
        | from
        | (select wswscs.d_week_seq d_week_seq1
        |        ,sun_sales sun_sales1
        |        ,mon_sales mon_sales1
        |        ,tue_sales tue_sales1
        |        ,wed_sales wed_sales1
        |        ,thu_sales thu_sales1
        |        ,fri_sales fri_sales1
        |        ,sat_sales sat_sales1
        |  from wswscs,date_dim
        |  where date_dim.d_week_seq = wswscs.d_week_seq and
        |        d_year = 2001) y,
        | (select wswscs.d_week_seq d_week_seq2
        |        ,sun_sales sun_sales2
        |        ,mon_sales mon_sales2
        |        ,tue_sales tue_sales2
        |        ,wed_sales wed_sales2
        |        ,thu_sales thu_sales2
        |        ,fri_sales fri_sales2
        |        ,sat_sales sat_sales2
        |  from wswscs
        |      ,date_dim
        |  where date_dim.d_week_seq = wswscs.d_week_seq and
        |        d_year = 2001+1) z
        | where d_week_seq1=d_week_seq2-53
        | order by d_week_seq1
        |""".stripMargin).collect()
  }

  def query2Parquet(spark: SparkSession): Unit = {
    spark.sql(
      """
        |with wscs as
        | (select sold_date_sk
        |        ,sales_price
        |  from (select ws_sold_date_sk sold_date_sk
        |              ,ws_ext_sales_price sales_price
        |        from web_sales_parquet) x
        |        union all
        |       (select cs_sold_date_sk sold_date_sk
        |              ,cs_ext_sales_price sales_price
        |        from catalog_sales_parquet)),
        | wswscs as
        | (select d_week_seq,
        |        sum(case when (d_day_name='Sunday') then sales_price else null end) sun_sales,
        |        sum(case when (d_day_name='Monday') then sales_price else null end) mon_sales,
        |        sum(case when (d_day_name='Tuesday') then sales_price else  null end) tue_sales,
        |        sum(case when (d_day_name='Wednesday') then sales_price else null end) wed_sales,
        |        sum(case when (d_day_name='Thursday') then sales_price else null end) thu_sales,
        |        sum(case when (d_day_name='Friday') then sales_price else null end) fri_sales,
        |        sum(case when (d_day_name='Saturday') then sales_price else null end) sat_sales
        | from wscs
        |     ,date_dim_parquet
        | where d_date_sk = sold_date_sk
        | group by d_week_seq)
        | select d_week_seq1
        |       ,round(sun_sales1/sun_sales2,2)
        |       ,round(mon_sales1/mon_sales2,2)
        |       ,round(tue_sales1/tue_sales2,2)
        |       ,round(wed_sales1/wed_sales2,2)
        |       ,round(thu_sales1/thu_sales2,2)
        |       ,round(fri_sales1/fri_sales2,2)
        |       ,round(sat_sales1/sat_sales2,2)
        | from
        | (select wswscs.d_week_seq d_week_seq1
        |        ,sun_sales sun_sales1
        |        ,mon_sales mon_sales1
        |        ,tue_sales tue_sales1
        |        ,wed_sales wed_sales1
        |        ,thu_sales thu_sales1
        |        ,fri_sales fri_sales1
        |        ,sat_sales sat_sales1
        |  from wswscs,date_dim_parquet
        |  where date_dim_parquet.d_week_seq = wswscs.d_week_seq and
        |        d_year = 2001) y,
        | (select wswscs.d_week_seq d_week_seq2
        |        ,sun_sales sun_sales2
        |        ,mon_sales mon_sales2
        |        ,tue_sales tue_sales2
        |        ,wed_sales wed_sales2
        |        ,thu_sales thu_sales2
        |        ,fri_sales fri_sales2
        |        ,sat_sales sat_sales2
        |  from wswscs
        |      ,date_dim_parquet
        |  where date_dim_parquet.d_week_seq = wswscs.d_week_seq and
        |        d_year = 2001+1) z
        | where d_week_seq1=d_week_seq2-53
        | order by d_week_seq1
        |""".stripMargin).collect()
  }

  def createTable(spark: SparkSession): Unit = {
    spark.sql("drop table if exists web_sales")
    spark.sql(
      """
        | create table if not exists web_sales
        |(
        |    ws_sold_date_sk           int,
        |    ws_sold_time_sk           int,
        |    ws_ship_date_sk           int,
        |    ws_item_sk                int,
        |    ws_bill_customer_sk       int,
        |    ws_bill_cdemo_sk          int,
        |    ws_bill_hdemo_sk          int,
        |    ws_bill_addr_sk           int,
        |    ws_ship_customer_sk       int,
        |    ws_ship_cdemo_sk          int,
        |    ws_ship_hdemo_sk          int,
        |    ws_ship_addr_sk           int,
        |    ws_web_page_sk            int,
        |    ws_web_site_sk            int,
        |    ws_ship_mode_sk           int,
        |    ws_warehouse_sk           int,
        |    ws_promo_sk               int,
        |    ws_order_number           int,
        |    ws_quantity               int,
        |    ws_wholesale_cost         decimal(7,2),
        |    ws_list_price             decimal(7,2),
        |    ws_sales_price            decimal(7,2),
        |    ws_ext_discount_amt       decimal(7,2),
        |    ws_ext_sales_price        decimal(7,2),
        |    ws_ext_wholesale_cost     decimal(7,2),
        |    ws_ext_list_price         decimal(7,2),
        |    ws_ext_tax                decimal(7,2),
        |    ws_coupon_amt             decimal(7,2),
        |    ws_ext_ship_cost          decimal(7,2),
        |    ws_net_paid               decimal(7,2),
        |    ws_net_paid_inc_tax       decimal(7,2),
        |    ws_net_paid_inc_ship      decimal(7,2),
        |    ws_net_paid_inc_ship_tax  decimal(7,2),
        |    ws_net_profit             decimal(7,2)
        |) using carbondata
        |""".stripMargin)

    spark.sql("drop table if exists catalog_sales")
    spark.sql(
      """
        |create table if not exists catalog_sales
        |(
        |    cs_sold_date_sk           int,
        |    cs_sold_time_sk           int,
        |    cs_ship_date_sk           int,
        |    cs_bill_customer_sk       int,
        |    cs_bill_cdemo_sk          int,
        |    cs_bill_hdemo_sk          int,
        |    cs_bill_addr_sk           int,
        |    cs_ship_customer_sk       int,
        |    cs_ship_cdemo_sk          int,
        |    cs_ship_hdemo_sk          int,
        |    cs_ship_addr_sk           int,
        |    cs_call_center_sk         int,
        |    cs_catalog_page_sk        int,
        |    cs_ship_mode_sk           int,
        |    cs_warehouse_sk           int,
        |    cs_item_sk                int,
        |    cs_promo_sk               int,
        |    cs_order_number           int,
        |    cs_quantity               int,
        |    cs_wholesale_cost         decimal(7,2),
        |    cs_list_price             decimal(7,2),
        |    cs_sales_price            decimal(7,2),
        |    cs_ext_discount_amt       decimal(7,2),
        |    cs_ext_sales_price        decimal(7,2),
        |    cs_ext_wholesale_cost     decimal(7,2),
        |    cs_ext_list_price         decimal(7,2),
        |    cs_ext_tax                decimal(7,2),
        |    cs_coupon_amt             decimal(7,2),
        |    cs_ext_ship_cost          decimal(7,2),
        |    cs_net_paid               decimal(7,2),
        |    cs_net_paid_inc_tax       decimal(7,2),
        |    cs_net_paid_inc_ship      decimal(7,2),
        |    cs_net_paid_inc_ship_tax  decimal(7,2),
        |    cs_net_profit             decimal(7,2)
        |) using carbondata
        |""".stripMargin)

    spark.sql("drop table if exists date_dim")
    spark.sql(
      """
        |create table if not exists date_dim
        |(
        |    d_date_sk                 int,
        |    d_date_id                 string,
        |    d_date                    date,
        |    d_month_seq               int,
        |    d_week_seq                int,
        |    d_quarter_seq             int,
        |    d_year                    int,
        |    d_dow                     int,
        |    d_moy                     int,
        |    d_dom                     int,
        |    d_qoy                     int,
        |    d_fy_year                 int,
        |    d_fy_quarter_seq          int,
        |    d_fy_week_seq             int,
        |    d_day_name                string,
        |    d_quarter_name            string,
        |    d_holiday                 string,
        |    d_weekend                 string,
        |    d_following_holiday       string,
        |    d_first_dom               int,
        |    d_last_dom                int,
        |    d_same_day_ly             int,
        |    d_same_day_lq             int,
        |    d_current_day             string,
        |    d_current_week            string,
        |    d_current_month           string,
        |    d_current_quarter         string,
        |    d_current_year            string
        |) using carbondata
        |""".stripMargin)
  }



  def loaddata(spark: SparkSession): Unit = {
    spark.sql(
      """
        |load data inpath '/opt/bigdata/data/tpcds/web_sales.dat' into table web_sales options('delimiter'='|', 'header'='false')
        |""".stripMargin)

    spark.sql(
      """
        |load data inpath '/opt/bigdata/data/tpcds/catalog_sales.dat' into table catalog_sales options('delimiter'='|', 'header'='false')
        |""".stripMargin)

    spark.sql(
      """
        |load data inpath '/opt/bigdata/data/tpcds/date_dim.dat' into table date_dim options('delimiter'='|', 'header'='false','DATEFORMAT'='yyyy-MM-dd')
        |""".stripMargin)
  }

}
